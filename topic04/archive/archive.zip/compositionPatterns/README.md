This folder contains the Sample App code used in the lectur on composition design patterns. It was created with the create-react-app tool.

Before running the code, you must add your TMDB API key to the .env file.

To run the app:

$ npm install
$ npm start

The code demonstrates two design patterns:
- Render Prop
- Higher Order Component - you must edit src/index.js to switch to the HOC demonstration. Change the third import statement to: import App from './App2'
