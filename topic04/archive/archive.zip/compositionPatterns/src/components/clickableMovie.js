import React from "react";
import withClicker from "../hoc/withClicker";

const Movie = (props) => {
  const borderStyle = props.clicked ? "border" : "";

  return (
    <li className={borderStyle}>
      <h2>{props.movie.title}</h2>
      <p>{props.movie.release_date}</p>
    </li>
  );
};

export default withClicker(Movie);
