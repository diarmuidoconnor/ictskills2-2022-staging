import React from "react";
import withClicker from "../hoc/withClicker";

const Friend = (props) => {

  return (
    <li>
      <h3>{` ${props.friend.name.first} ${props.friend.name.last}`}</h3>
      <img src={props.friend.picture.medium} />
      {props.clicked ? <button>Do Action</button> : <></>}
    </li>
  );
};

export default withClicker(Friend);
