import React from "react";
import withClicker from "../hoc/withClicker";

const Friend = (props) => {
  const border = props.clicked ? "border" : "";

  return (
    <li className={border}>
      <h3>{` ${props.friend.name.first} ${props.friend.name.last}`}</h3>
      <a href={"mailto:" + props.friend.email}>{props.friend.email} </a>
    </li>
  );
};

export default withClicker(Friend);
