import React, { useState, useEffect } from "react";
import "./style.css";
import ClickableFriend from "./components/clickableFriend";
import ClickableMovie from "./components/clickableMovie";

const App = () => {
  const [movies, setMovies] = useState([]);
  const [friends, setFriends] = useState([]);

  useEffect(() => {
    fetch("https://randomuser.me/api/?results=10")
      .then((response) => response.json())
      .then((json) => {
        setFriends(json.results);
      });
  }, []);

  useEffect(() => {
    fetch(
      `https://api.themoviedb.org/3/discover/movie?api_key=${process.env.REACT_APP_TMDB_KEY}&language=en-US&include_adult=false&include_video=false&page=1`
    )
      .then((response) => response.json())
      .then((json) => {
        setMovies(json.results);
      });
  }, []);

  return (
    <div className="row">
      <div className="column">
        <h1>Friends List</h1>
        <ul>
          {friends.map((friend) => (
            <ClickableFriend key={friend.email} friend={friend} />
          ))}
        </ul>
      </div>
      <div className="column">
        <h1>Movie List</h1>
        <ul>
          {movies.map((movie) => (
            <ClickableMovie key={movie.id} movie={movie} />
          ))}
        </ul>
      </div>
    </div>
  );
};

export default App;
