import { useState } from "react";

const withClickable = (Component) => {
  return ({ ...props }) => {
    const [clicked, setClicked] = useState(false);
    const onClick = () => setClicked(!clicked);
    return (
      <div onClick={onClick}>
        <Component {...props} clicked={clicked} />
      </div>
    );
  };
};

export default withClickable;
