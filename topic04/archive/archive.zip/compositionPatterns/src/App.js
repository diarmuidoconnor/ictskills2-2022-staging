import React, { useState, useEffect } from "react";
import FilteredFriendList from "./components/filteredFriendList";
import "./style.css";
import FriendContact from "./components/friendContact";
// import FriendImage from './components/friendImage'

const FriendsApp = () => {
  const [searchText, setSearchText] = useState("");
  const [friends, setFriends] = useState([]);

  useEffect(() => {
    fetch("https://randomuser.me/api/?results=10")
      .then((response) => response.json())
      .then((json) => {
        setFriends(json.results);
      });
  }, []);

  const filterChange = (event) => {
    event.preventDefault();
    setSearchText(event.target.value.toLowerCase());
  };

  const filteredList = friends.filter((friend) => {
    const friendName = friend.name.last.toLowerCase();
    return friendName.search(searchText) !== -1;
  });

  return (
    <>
      <h1>Friends List</h1>
      <input type="text" placeholder="Search" onChange={filterChange} />
      <FilteredFriendList
        list={filteredList}
        render={(friend) => <FriendContact friend={friend} />}
      />
    </>
  );
};

export default FriendsApp;
