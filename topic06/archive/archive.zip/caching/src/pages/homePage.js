import React, { useState, useEffect } from "react";
import FilteredMovieList from "../components/filteredMovieList";
import { getMovies } from "../api";
import { useQuery } from "react-query";

const HomePage = () => {
  const [searchText, setSearchText] = useState("");

  const [movies, setMovies] = useState([]);

  useEffect(async () => {
    const response = await getMovies();
    setMovies(response.results);
  }, []);
  
  const filterChange = (event) => {
    event.preventDefault();
    setSearchText(event.target.value.toLowerCase());
  };
  const filteredList = movies.filter((movie) => {
    const title = movie.title.toLowerCase();
    return title.search(searchText) !== -1;
  });
 
  console.log("Render FriendsApp");
  return (
    <>
      <h1>Movie List</h1>
      <input type="text" placeholder="Search" onChange={filterChange} />
      <FilteredMovieList list={filteredList} />
    </>
  );
};

export default HomePage;
