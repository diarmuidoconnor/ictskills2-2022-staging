import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter, Route, Redirect, Switch, Link } from "react-router-dom";
import { About } from "../sample1";

const Inbox = props => {
  const { user, beta } = props.location.state;
  return (
    <>
      <h2>Inbox page</h2>
      <p>{`Link Props: ${user}, ${beta}`}</p>
    </>
  );
};

const Home = () => {
  const userId = 'id1234'
  const beta = 'something else'
  return (
    <>
      <ul>
        <li>
          <Link to="/about">About</Link>
        </li>
        <li>
          <Link
            to={{
              pathname: "/inbox",
              state: {
                user: userId,
                beta: beta
              }
            }}
          >
            Inbox<span> (Link with extra props)</span>{" "}
          </Link>
          
        </li>
      </ul>
      <h1>Home page</h1>
      <h3>Demos passing additional props with a Link</h3>
    </>
  );
};

const App = () => {
  return (
    <BrowserRouter>
      <Switch>
        <Route path="/about" component={About} />
        <Route path="/inbox" component={Inbox} />
        <Route exact path="/" component={Home} />
        <Redirect from="*" to="/" />
      </Switch>
    </BrowserRouter>
  );
};

ReactDOM.render(<App />, document.getElementById("root"));
