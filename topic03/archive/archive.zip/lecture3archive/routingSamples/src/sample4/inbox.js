import React from "react";
import { withRouter, Route } from "react-router-dom";

const BaseInbox = (props) => {
  return (
    <>
      <h1>Inbox page</h1>
      <Messages id={props.match.params.userId} />
      <Route path={`/inbox/:userId/statistics`} component={Stats} />
      <Route path={`/inbox/:userId/drafts`} component={Draft} />
    </>
  );
};

export const Messages = (props) => {
  return <h3>Messages for user: {props.id} </h3>;
};

const Stats = () => {
  return <h3>Statistical data</h3>;
};

const Draft = () => {
  return <h3>Draft emails</h3>;
};

export default withRouter(BaseInbox);
