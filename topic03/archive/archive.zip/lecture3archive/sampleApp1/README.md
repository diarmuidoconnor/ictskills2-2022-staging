This folder contains the Sample App code discussed in the lecture - the
Filtered Friends app. It was created with the create-react-app tool.

To run it:

$ npm install
$ npm start

The code demonstrates:
- Uni-directional data flow.
- The useEffect and useState hooks.